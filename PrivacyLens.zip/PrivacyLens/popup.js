const items = [
  { icon: "📡", name: "ads.trackernet.io", tag: "Blocked", cls: "blocked",
    detail: "Attempted to load a third-party ad tracker. Request was blocked before it reached the network." },
  { icon: "🍪", name: "session_id", tag: "Allowed", cls: "allowed",
    detail: "First-party cookie used for keeping you logged in. No cross-site sharing detected." },
  { icon: "🖐", name: "Canvas fingerprint", tag: "Flagged", cls: "flagged",
    detail: "Page attempted to read canvas pixel data, a common fingerprinting technique. Allowed but logged." }
];

const listEl = document.getElementById("detectedList");

items.forEach(it => {
  const row = document.createElement("div");
  row.className = "list-item";
  row.innerHTML = `
    <div class="row-head">
      <div class="row-left">
        <span class="row-icon">${it.icon}</span>
        <span class="row-name">${it.name}</span>
      </div>
      <div class="row-right">
        <span class="tag ${it.cls}">${it.tag}</span>
        <span class="chev">▾</span>
      </div>
    </div>
    <div class="row-detail"><p>${it.detail}</p></div>
  `;
  listEl.appendChild(row);

  const head = row.querySelector(".row-head");
  const detail = row.querySelector(".row-detail");
  const chev = row.querySelector(".chev");
  head.addEventListener("click", () => {
    const isOpen = detail.style.maxHeight && detail.style.maxHeight !== "0px";
    detail.style.maxHeight = isOpen ? "0px" : "90px";
    chev.style.transform = isOpen ? "rotate(0deg)" : "rotate(180deg)";
  });
});

function animateCount(el, target, duration) {
  const t0 = performance.now();
  function step(t) {
    const p = Math.min((t - t0) / duration, 1);
    el.textContent = Math.round(target * p);
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

function loadAndAnimate() {
  chrome.storage.local.get(
    ["score", "trackersBlocked", "cookiesSeen", "fingerprintAttempts", "protectionOn"],
    (data) => {
      const score = data.score ?? 82;
      const ring = document.getElementById("ringFill");
      const circumference = 327;
      setTimeout(() => {
        ring.style.strokeDashoffset = circumference - (circumference * score) / 100;
        animateCount(document.getElementById("scoreNum"), score, 900);
        document.querySelectorAll(".stat-num").forEach((el) => {
          animateCount(el, parseInt(el.dataset.target, 10), 900);
        });
      }, 150);
    }
  );
}

// Fallback for viewing popup.html outside the extension (no chrome.storage)
if (typeof chrome === "undefined" || !chrome.storage) {
  window.chrome = { storage: { local: {
    get: (_keys, cb) => cb({ score: 82, trackersBlocked: 14, cookiesSeen: 6, fingerprintAttempts: 2, protectionOn: true })
  }}};
}
loadAndAnimate();

const toggle = document.getElementById("protectToggle");
const toggleLabel = toggle.querySelector(".toggle-label");
toggle.addEventListener("click", () => {
  const nowOn = !toggle.classList.contains("on");
  toggle.classList.toggle("on", nowOn);
  toggle.classList.toggle("off", !nowOn);
  toggle.setAttribute("aria-pressed", String(nowOn));
  toggleLabel.textContent = nowOn ? "Protected" : "Paused";
  chrome.storage.local.set({ protectionOn: nowOn });
});

const scanBtn = document.getElementById("scanBtn");
const scanIcon = scanBtn.querySelector(".scan-icon");
const scanText = scanBtn.querySelector(".scan-text");
const scanMsg = document.getElementById("scanMsg");
scanBtn.addEventListener("click", () => {
  scanBtn.disabled = true;
  scanIcon.classList.add("spin");
  scanText.textContent = "Scanning…";
  setTimeout(() => {
    scanBtn.disabled = false;
    scanIcon.classList.remove("spin");
    scanText.textContent = "Run scan";
    scanMsg.style.opacity = "1";
    setTimeout(() => (scanMsg.style.opacity = "0"), 1500);
  }, 900);
});
