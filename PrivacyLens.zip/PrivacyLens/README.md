# PrivacyLens

A Chrome extension popup that shows a live privacy score, trackers blocked,
cookies seen, and fingerprinting attempts for the current page.

## Run it locally

1. Open `chrome://extensions`
2. Turn on **Developer mode** (top right)
3. Click **Load unpacked** and select this folder
4. Click the PrivacyLens icon in your toolbar

The popup currently shows placeholder numbers set in `background.js`.
Wire up real detection in Stages 2–4 (network requests, cookies,
fingerprinting) and write the results to `chrome.storage.local` — the
popup already reads from there.

## Files

- `manifest.json` — extension config (Manifest V3)
- `background.js` — service worker, sets placeholder data on install
- `popup.html` / `popup.css` / `popup.js` — the dashboard UI

## Push this to GitHub

From inside this folder:

```bash
git init
git add .
git commit -m "Initial PrivacyLens popup UI"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/privacylens.git
git push -u origin main
```

Create the empty repo first at https://github.com/new (name it e.g.
`privacylens`, don't initialize it with a README so the push above
doesn't conflict).
