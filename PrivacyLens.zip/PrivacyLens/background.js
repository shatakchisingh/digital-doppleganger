console.log("PrivacyLens started!");

// Stage 2+ will fill this in: listen to chrome.webRequest and chrome.cookies,
// tally counts per tab, and write them to chrome.storage so popup.js can read them.

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    score: 82,
    trackersBlocked: 14,
    cookiesSeen: 6,
    fingerprintAttempts: 2,
    protectionOn: true
  });
});
